#ifndef GETEXCLUSIONSIGNIFICANCE_H
#define GETEXCLUSIONSIGNIFICANCE_H

double getExclusionSignificance(double mu, double n, double s,
       vector<double> m, vector<double> tau);

#endif
