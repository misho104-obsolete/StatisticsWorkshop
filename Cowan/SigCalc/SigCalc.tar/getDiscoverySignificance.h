#ifndef GETDISCOVERYSIGNIFICANCE_H
#define GETDISCOVERYSIGNIFICANCE_H

double getDiscoverySignificance(double n, double s,
       vector<double> m, vector<double> tau);

#endif
